/**
 * A boolean condition with parameter x that can be applied to
 * a string.  Returns true if the string is longer than x; false
 * otherwise.
 * CS2030S Lab 4
 * AY22/23 Semester 2
 *
 * @author Ng Yu Soon (Lab Group 12C)
 */
import java.lang.String;

class LongerThan implements BooleanCondition<String> {
  private int x;

  public LongerThan(int x) {
    this.x = x;
  }

  @Override
  public boolean test(String s) {
    if (s.length() > this.x) {
      return true;
    }
    return false;
  }
}
