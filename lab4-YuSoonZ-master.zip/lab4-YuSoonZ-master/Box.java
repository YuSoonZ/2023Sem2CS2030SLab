/**
 * A generic box storing an item.
 * CS2030S Lab 4
 * AY22/23 Semester 2
 *
 * @author Ng Yu Soon (Lab Group 12C)
 */


class Box<T> {
  private final T content;
  private static final Box<?> EMPTY_BOX = new Box<>(null);

  private Box(T content) {
    this.content = content;
  }

  public static <T> Box<T> empty() {
    // Typecasting the EMPTY_BOX to be of type T
    @SuppressWarnings("unchecked")
    Box<T> box = (Box<T>) EMPTY_BOX;
    return box;
  }

  public static <T> Box<T> ofNullable(T item) {
    if (item == null) {
      return empty();
    }
    return new Box<>(item);
  }

  public boolean isPresent() {
    return this.content != null;
  }


  public static <U> Box<U> of(U item) {
    if (item != null) {
      return new Box<>(item);
    }
    return null;
  }

  public Box<T> filter(BooleanCondition<? super T> condition) {
    if (content == null) {
      return empty();
    }
    if (!condition.test(content)) {
      return empty();
    }
    return this;
  }

  public <U> Box<U> map(Transformer<? super T, U> transformer) {
    if (this == EMPTY_BOX) {
      return empty();
    }
    return ofNullable(transformer.transform(content));
  }

  @Override
  public boolean equals(Object obj) {
    if (obj == this) {
      return true;
    }
    if (obj instanceof Box<?>) {
      Box<?> b = (Box<?>) obj;
      if (this.content == b.content) {
        return true;
      }
      if (this.content == null || b.content == null) {
        return false;
      }
      return this.content.equals(b.content);
    }
    return false;
  }
  
  @Override
  public String toString() {
    if (this.content == null) {
      return "[]";
    }
    return "[" + this.content + "]";
  }

}
