/**
 * A transformer with a parameter k that takes in an object x 
 * and outputs the last k digits of the hash value of x.
 * CS2030S Lab 4
 * AY22/23 Semester 2
 *
 * @author Ng Yu Soon (Lab Group 12C)
 */
import java.util.Objects;
import java.lang.String;

class LastDigitsOfHashCode implements Transformer<Object, Integer> {
  private final int k;

  public LastDigitsOfHashCode(int k) {
    this.k = k;
 }

  @Override 
  public Integer transform(Object x) {
    int code = Objects.hashCode(x);
    String str = String.valueOf(code);
    int lastkDigits;
    if (k >= str.length()) {
      lastkDigits = Integer.parseInt(str);
    } else {
      String lastk = str.substring(Math.max(str.length() - k, 0));
      lastkDigits = Integer.parseInt(lastk);
    }
    return lastkDigits;
  }
}
