# CS2030S AY22/23 Sem 2 Lab 4
## Feedback for YuSoonZ
`checkstyle` detected 2 violation of Java style guide in your code.

The tutor has marked your code. You can find [the comments from your tutor here](https://www.github.com/nus-cs2030s-2223-s2/lab4-YuSoonZ/commit/7e9836e0b14164242c5d64e6fd8041c6e2bc7fc7).
### Summary

| Component | Marks |
|-----------|-------|
| Style | 1.5 |
| Marks | 12 |
| **TOTAL** | 13.5 |
